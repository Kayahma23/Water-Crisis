pandaConfig = {
    name: 'MyPandaGame',
    version: '0.0.0',

    system: {
        width: 1920,
        height: 1024
    }
};
