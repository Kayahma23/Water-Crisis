game.module(
    'game.assets'
)
.body(function() {
    
game.addAsset('01_sky_moon.png');
game.addAsset('03_city.png');
game.addAsset('04_city.png');
game.addAsset('05_trees.png');
game.addAsset('05_bush.png');
game.addAsset('platform.png');
game.addAsset('tires.png');
game.addAsset('player.json');
game.addAsset('coin.json');
game.addAsset('oneway.png');
game.addAsset('bigbackground.png');
game.addAsset('boat.png');
game.addAsset('waves.png');
game.addAsset('indianapolis.png');
game.addAsset('newark.png');
game.addAsset('ciniccnati.png');
game.addAsset('michigan.png');
game.addAsset('pittsburgh.png');
game.addAsset('junk.png')
game.addAsset('trees.png')
game.addAsset('leaves.png')

});
