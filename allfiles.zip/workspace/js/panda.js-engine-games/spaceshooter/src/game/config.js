pandaConfig = {
    name: 'Space Shooter',
    version: '0.0.0',

    system: {
        width: 1920,
        height: 1080,
        scaleMode: 'nearest'
    }
};
