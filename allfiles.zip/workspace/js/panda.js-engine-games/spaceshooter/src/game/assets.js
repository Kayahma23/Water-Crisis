game.module(
    'game.assets'
)
.body(function() {
    
game.addAsset('desert-backgorund-looped.png');
game.addAsset('enemy-small.png');
game.addAsset('explosion.png');
game.addAsset('fire.png');
game.addAsset('laser-bolts.png');
game.addAsset('ship.png');

});
