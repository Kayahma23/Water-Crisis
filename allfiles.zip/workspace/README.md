# Water-Crisis

# What this project does?
 It's purpose is to deliver water to water polluted cities including Hoosick,Newark,Cincinatti,and Flint.
 
# How we built it?
 We devided the work amongst the five of us used panda game framework.
 
# Challenges we ran into?
 Ran into challenges with the score, sprites, getting panda to work.
 
# What we learned?
 We learned that even though the U.S is a first world country we still have pollution problems.
 
# What is next for this project?
 Add a mini game for each city.
